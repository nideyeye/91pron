from django.shortcuts import render #引入 Django 自带的渲染函数
from spider import * #导入爬虫类
from django.http import HttpResponse #导入简单响应
 
# Create your views here.
def index(request):
    return render(request,'my91/index.html')
    
def video(request):
    print(request)
    url_1 = request.GET['url_1'] #获得网址中 url_1 的值
    free_url = request.GET['free_url']
    temp = Spider_91() #继承爬虫类
    #temp.set_url('http://92.91p08.space') #设置爬虫类的起始网页
    temp.set_url(str(free_url))
    next_page = int(url_1) + 1 #将采集到的页码加一用于翻页
    result = temp.run(url_1) #得到爬虫类的返回值
    return render(request, 'my91/video.html', {'urls':result, 'next_page':next_page, 'free_url':free_url}) #返回 video 网页，并将返回值与页码传入
