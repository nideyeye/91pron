#！/usr/bin/env python
# _*_coding:utf-8 _*_
from django.urls import path
from django.contrib import admin
from . import views

urlpatterns = [
    path('', views.index, name = 'home'),
    path('video/', views.video, name = 'video')
]
