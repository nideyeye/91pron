from django.apps import AppConfig


class My91Config(AppConfig):
    name = 'my91'
