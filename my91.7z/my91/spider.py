#-*- coding = utf-8 -*-
import requests
from bs4 import BeautifulSoup
import time, random
import threading
import queue

class Spider_91():
    def __init__(self):
        self.main_url = 'http://91porn.com/video.php?category=rf&page='#设置热点网页地址
        self.play_url = []
    def set_url(self, url):
        self.base_url = '/video.php?category=rf&page='
        self.main_url = url + self.base_url#设置热点网页地址
    def fake_headers(self):#返回一个爬虫用的请求头
        randomIP = str(random.randint(0, 255)) + "." + str(random.randint(0,255)) + "." + str(random.randint(0,255)) + "." + str(random.randint(0,255))
        headers = {'Accept-Language':'zh-CN,zh;q=0.9','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36Name','Referer':'http://91porn.com','X-Forwarded-For':randomIP}
        return headers
        
    def parse_web(self, q, page):#解析对应页面，返回待处理的字典文件
        url = self.main_url + str(page)
        raw_web =requests.get(url, headers=self.fake_headers(), timeout = 15)
        raw_web.encoding = 'utf-8'
        detail_list=[]
        data = BeautifulSoup(raw_web.text, 'lxml')
    
        try:
            detail_urls = data.select('div.listchannel')
            for detail in detail_urls:
                dic_massage={}
                title = str(detail.a.img['title'])#解析影片题目
                url = str(detail.a['href'])#解析视频地址
                img = str(detail.a.img['src'])#解析视频封面图
                dic_massage[title]=detail_list
                dic_massage[title].append(img)
                dic_massage[title].append(url)
                q.put(dic_massage)#返回数据文件，格式{'片名':['图片地址','视频地址']}
            print('页面解析完成，准备分析视频地址')
        except:
            print('页面解析出现错误，即将保存页面进行分析')
            f = open('worong_html'+int(time.time())+'.html', 'wb')
            f.write(raw_web.content)
            f.close()
        
        
    def get_real_url(self, q):#解析真实地址
            while True:
                try:
                    dir_91 = q.get(timeout = 7)
                    for name in dir_91.keys():
                        url = dir_91[name][1]
                        video_urls={}
                        web_data = requests.get(url, headers=self.fake_headers(), timeout = 7)
                        soup = BeautifulSoup(web_data.text, 'lxml')
                        for i in soup.select('source'):
                            if i['src']:
                                video_urls[name]=str(i['src'])
                                print(video_urls)
                            else:
                                pass
                        self.play_url.append(video_urls)#返回真实地址
                except:
                    break
    def run(self,page):
        q = queue.Queue()
        t1 = threading.Thread(target = self.parse_web, args =(q,page,))
        t2 = threading.Thread(target = self.get_real_url, args =(q,))
        t3 = threading.Thread(target = self.get_real_url, args =(q,))
        t4 = threading.Thread(target = self.get_real_url, args =(q,))
        threads = []
        threads.append(t1)#解析当前页详情链接
        threads.append(t2)#解析视频真实地址线程1
        threads.append(t3)#解析视频真实地址线程2
        threads.append(t4)#解析视频真实地址线程2
        
        for t in threads:
            t.start()
            print('多线程已启动')
        t.join()
        return self.play_url
if __name__ == '__main__':
    temp = Spider_91()
    temp.set_url('http://92.91p08.space')
    result = temp.run(2)
    print(result)